# Connected carousels
Build a single N×W by H scene and clip it into N slides. Shared background coordinates, product scale and lighting must stay identical across slices. Do not rebuild each slide independently with slightly different crops.

Useful connections, chosen to fit the approved style:
- A hero object extends 10–25% across the boundary; the next view remains recognizable in its own slide.
- A substantial background plane or photographic surface flows across the seam, if the style already supports it.
- A repeated structural feature continues physically, with product details leading the eye across the boundary.
Keep titles and important specifications inside their own slide. Do not split model names, logos or essential labels. Each slide must remain useful alone.

Two photos: slide 1 primary product with key facts; slide 2 alternate angle plus additional specs. Avoid making slide 2 an empty crop. Keep both photos distinguishable. Overlap only where it preserves product readability; do not merge two motors/devices into an impossible object. A decorative thin line alone is usually too weak a connection. Adding a new geometric panel changes the style and is inappropriate when the user requested only a connection fix.

Before rendering, mark the seam in review guides and check the actual clipping. Preview connected and separated. After feedback, inspect the selected version, retain approved style and copy, and change only the requested layout issue. Never silently export a rejected or older version.
